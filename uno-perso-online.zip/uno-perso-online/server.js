const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.use(express.static(path.join(__dirname, 'public')));

const rooms = new Map();
const COLORS = ['red','yellow','green','blue'];
const COLOR_NAMES = {red:'Rouge', yellow:'Jaune', green:'Vert', blue:'Bleu', black:'Noire'};

function code(){ let s=''; const a='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; for(let i=0;i<5;i++) s+=a[Math.floor(Math.random()*a.length)]; return s; }
function shuffle(a){ for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]];} return a; }
function makeDeck(){
  const d=[];
  for(const c of COLORS){
    d.push({c,v:'0',type:'num'});
    for(let i=1;i<=9;i++){ d.push({c,v:String(i),type:'num'}); d.push({c,v:String(i),type:'num'}); }
    for(const v of ['+2','⛔','⇄']){ d.push({c,v,type:v==='+2'?'+2':'special'}); d.push({c,v,type:v==='+2'?'+2':'special'}); }
  }
  for(let i=0;i<4;i++){ d.push({c:'black',v:'Couleur',type:'wild'}); d.push({c:'black',v:'+4',type:'+4'}); }
  return shuffle(d).map((card,i)=>({...card,id:Date.now().toString(36)+i.toString(36)+Math.random().toString(36).slice(2,5)}));
}
function draw(g){
  if(!g.deck.length){ const top=g.discard.pop(); g.deck=shuffle(g.discard); g.discard=[top]; }
  return g.deck.pop();
}
function label(c){ return `${COLOR_NAMES[c.c]||c.c} ${c.v}`; }
function points(c){ if(c.type==='num') return Number(c.v); if(c.v==='+4'||c.v==='Couleur') return 50; return 25; }
function same(a,b){ return a&&b&&a.c===b.c&&a.v===b.v; }
function canPlay(g,card){
  const top = g.discard.at(-1);
  if(g.pendingDraw>0){
    if(g.pendingMode === '+4') return card.type === '+4';
    return card.type === '+2' || card.type === '+4';
  }
  if(card.c==='black') return true;
  return card.c===top.c || card.v===top.v;
}
function publicState(g, forId){
  const me = g.players.find(p=>p.id===forId);
  return {
    room:g.code, hostId:g.hostId, started:g.started, roundOver:g.roundOver,
    current:g.current, direction:g.dir, pendingDraw:g.pendingDraw, pendingMode:g.pendingMode,
    lastCard:g.lastCard, topCard:g.discard.at(-1), log:g.log.slice(-60).reverse(),
    players:g.players.map((p,i)=>({id:p.id,name:p.name,cards:p.hand.length,score:p.score,saidUno:p.saidUno,active:i===g.current,connected:p.connected})),
    hand: me ? me.hand : [], myId: forId,
    intercepts: g.players.filter(p=>p.id!==forId).map(p=>({playerId:p.id,name:p.name,count:p.hand.filter(c=>same(c,g.lastCard)).length}))
  };
}
function emitRoom(g){ for(const p of g.players) io.to(p.socketId).emit('state', publicState(g,p.id)); }
function log(g,msg){ g.log.push(msg); }
function next(g){
  if(!g.players.length) return;
  let safe=0;
  do{
    g.current=(g.current+g.dir+g.players.length)%g.players.length; safe++;
    const p=g.players[g.current];
    if(p.skip){ log(g, `${p.name} passe son tour.`); p.skip=false; continue; }
    break;
  } while(safe<30);
}
function startRound(g, keepScores=true){
  const scores = keepScores ? g.players.map(p=>p.score) : g.players.map(()=>0);
  g.deck=makeDeck(); g.discard=[]; g.current=0; g.dir=1; g.pendingDraw=0; g.pendingMode=null; g.lastCard=null; g.roundOver=false; g.started=true;
  g.players.forEach((p,i)=>{p.hand=[]; p.score=scores[i]||0; p.saidUno=false; p.skip=false;});
  for(let r=0;r<7;r++) for(const p of g.players) p.hand.push(draw(g));
  let first; do { first=draw(g); } while(first.c==='black'||first.type!=='num');
  g.discard.push(first); log(g, `Nouvelle manche. Première carte : ${label(first)}.`);
}
function finishRound(g,winner){
  g.roundOver=true; log(g, `${winner.name} n’a plus de cartes : manche terminée !`);
  for(const p of g.players){ if(p.id!==winner.id){ const pts=p.hand.reduce((s,c)=>s+points(c),0); p.score+=pts; log(g, `${p.name} prend ${pts} points. Total : ${p.score}.`); } }
  const loser=g.players.find(p=>p.score>=500); if(loser) log(g, `PARTIE TERMINÉE : ${loser.name} atteint 500 points et perd.`);
}

io.on('connection', socket => {
  socket.on('createRoom', ({name})=>{
    const roomCode=code(); const id=socket.id;
    const g={code:roomCode,hostId:id,players:[{id,socketId:socket.id,name:name||'Joueur A',hand:[],score:0,saidUno:false,skip:false,connected:true}],deck:[],discard:[],current:0,dir:1,pendingDraw:0,pendingMode:null,lastCard:null,started:false,roundOver:false,log:[]};
    rooms.set(roomCode,g); socket.join(roomCode); socket.emit('joined',{room:roomCode}); emitRoom(g);
  });
  socket.on('joinRoom', ({room,name})=>{
    const g=rooms.get(String(room||'').toUpperCase());
    if(!g) return socket.emit('errorMsg','Salle introuvable.');
    if(g.started) return socket.emit('errorMsg','La partie a déjà commencé.');
    if(g.players.length>=10) return socket.emit('errorMsg','Salle pleine.');
    const p={id:socket.id,socketId:socket.id,name:name||`Joueur ${String.fromCharCode(65+g.players.length)}`,hand:[],score:0,saidUno:false,skip:false,connected:true};
    g.players.push(p); socket.join(g.code); socket.emit('joined',{room:g.code}); log(g, `${p.name} rejoint la salle.`); emitRoom(g);
  });
  socket.on('startGame', ({room})=>{ const g=rooms.get(room); if(!g||socket.id!==g.hostId) return; if(g.players.length<2) return socket.emit('errorMsg','Il faut au moins 2 joueurs.'); startRound(g,false); emitRoom(g); });
  socket.on('nextRound', ({room})=>{ const g=rooms.get(room); if(!g||socket.id!==g.hostId) return; startRound(g,true); emitRoom(g); });
  socket.on('playCard', ({room,cardId,color})=>{
    const g=rooms.get(room); if(!g||g.roundOver) return;
    const p=g.players[g.current]; if(!p||p.id!==socket.id) return socket.emit('errorMsg',"Ce n’est pas ton tour.");
    const idx=p.hand.findIndex(c=>c.id===cardId); if(idx<0) return;
    const card=p.hand[idx]; if(!canPlay(g,card)) return socket.emit('errorMsg','Carte interdite maintenant.');
    p.hand.splice(idx,1); p.saidUno=false; if(card.c==='black') card.c=color||'red';
    g.discard.push(card); g.lastCard=card; log(g, `${p.name} joue ${label(card)}.`);
    if(card.type==='+2'){ g.pendingDraw+=2; g.pendingMode=g.pendingMode||'+2'; }
    else if(card.type==='+4'){ g.pendingDraw+=4; g.pendingMode='+4'; }
    else if(card.v==='⇄'){ g.dir*=-1; if(g.players.length===2) next(g); }
    else if(card.v==='⛔'){ next(g); }
    if(p.hand.length===1) log(g, `${p.name} doit annoncer UNO !`);
    if(p.hand.length===0) finishRound(g,p);
    emitRoom(g);
  });
  socket.on('intercept', ({room,playerId})=>{
    const g=rooms.get(room); if(!g||g.roundOver||!g.lastCard) return;
    const p=g.players.find(x=>x.id===socket.id); if(!p) return;
    const idx=p.hand.findIndex(c=>same(c,g.lastCard)); if(idx<0) return socket.emit('errorMsg',"Tu n’as pas cette carte exacte.");
    const card=p.hand[idx]; p.hand.splice(idx,1); p.saidUno=false; g.current=g.players.findIndex(x=>x.id===p.id); g.discard.push(card); g.lastCard=card;
    log(g, `${p.name} intercepte avec ${label(card)} !`);
    if(card.type==='+2'){ g.pendingDraw+=2; g.pendingMode=g.pendingMode||'+2'; }
    else if(card.type==='+4'){ g.pendingDraw+=4; g.pendingMode='+4'; }
    if(p.hand.length===1) log(g, `${p.name} doit annoncer UNO !`);
    if(p.hand.length===0) finishRound(g,p);
    emitRoom(g);
  });
  socket.on('draw', ({room})=>{
    const g=rooms.get(room); if(!g||g.roundOver) return; const p=g.players[g.current]; if(!p||p.id!==socket.id) return;
    if(g.pendingDraw>0){ for(let i=0;i<g.pendingDraw;i++) p.hand.push(draw(g)); log(g, `${p.name} pioche la pénalité : +${g.pendingDraw}.`); g.pendingDraw=0; g.pendingMode=null; next(g); }
    else { p.hand.push(draw(g)); log(g, `${p.name} pioche 1 carte.`); }
    emitRoom(g);
  });
  socket.on('endTurn', ({room})=>{ const g=rooms.get(room); if(!g||g.roundOver) return; const p=g.players[g.current]; if(p?.id!==socket.id) return; next(g); emitRoom(g); });
  socket.on('uno', ({room})=>{ const g=rooms.get(room); if(!g) return; const p=g.players.find(x=>x.id===socket.id); if(!p) return; if(p.hand.length===1){p.saidUno=true; log(g, `${p.name} annonce UNO !`);} else socket.emit('errorMsg','UNO seulement quand il te reste 1 carte.'); emitRoom(g); });
  socket.on('unoFault', ({room})=>{ const g=rooms.get(room); if(!g) return; const offender=g.players.find(p=>p.hand.length===1&&!p.saidUno); if(!offender){socket.emit('errorMsg','Aucun oubli détecté.'); return;} offender.hand.push(draw(g),draw(g)); offender.skip=true; log(g, `${offender.name} a oublié UNO : +2 cartes et prochain tour passé.`); emitRoom(g); });
  socket.on('disconnect', ()=>{ for(const g of rooms.values()){ const p=g.players.find(x=>x.id===socket.id); if(p){p.connected=false; log(g, `${p.name} est déconnecté.`); emitRoom(g);} } });
});

server.listen(process.env.PORT || 3000, () => console.log('UNO perso online ready'));
